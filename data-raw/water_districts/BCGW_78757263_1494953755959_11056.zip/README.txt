E00 files created by Distribution Service do not automatically create
regions for overlapping polygons. Please run the "polyregion" command on
the imported coverage before a clean or build if regions are required.
If the dataset is not topologically correct, this will not solve the
issue with your regions and you should immediately download the shape
file to work with and contact the "Data Custodian - Point of Contact"
from the metadata record with your concerns.  This is not a data
download issue, as the download tool does not force topological
integrity.

For further notices about download issues, please refer to
http://www.data.gov.bc.ca/dbc/geo/distribution/news.page
